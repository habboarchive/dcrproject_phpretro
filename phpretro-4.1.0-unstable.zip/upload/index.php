<?php
/*================================================================+\
|| # PHPRetro - An extendable virtual hotel site and management
|+==================================================================
|| # Copyright (C) 2009 PHPRetro. All rights reserved.
|| # http://code.google.com/p/phpretro
|| # Parts Copyright (C) 2009 Meth0d. All rights reserved.
|| # http://www.meth0d.org
|| # All images, scripts, and layouts
|| # Copyright (C) 2009 Sulake Ltd. All rights reserved.
|+==================================================================
|| # PHPRetro is provided "as is" and comes without
|| # warrenty of any kind. PHPRetro is free software!
|| # License: GNU Public License 3.0
|| # http://opensource.org/licenses/gpl-license.php
\+================================================================*/

require_once('./includes/core.php');
$page['name'] = $lang->loc['pagename.home'];
$page['bodyid'] = "frontpage";
if($user->id > 0){ header("Location:".PATH."/me"); }
if(isset($_GET['error'])){
	$errorno = $_GET['error'];
	if($errorno == 1){
		$login_error = $lang->loc['error.1'];
	} elseif($errorno == 2){
		$login_error = $lang->loc['error.1'];
	} elseif(isset($_GET['ageLimit']) && $_GET['ageLimit'] == "true"){
		$login_error = $lang->loc['error.5'];
	}
}
$username = $input->HoloText($_GET['username']);
$rememberme = $input->HoloText($_GET['rememberme']);
$pageto = $input->HoloText($_GET['page']);
if(!isset($_SESSION['login'])){
	$_SESSION['login']['enabled'] = true;
	$_SESSION['login']['tries'] = 0;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php echo SHORTNAME; ?>: Create your avatar, decorate your room, chat and make new friends. </title>
<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="<?php echo PATH; ?>/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="alternate" type="application/rss+xml" title="<?php echo SHORTNAME; ?>: <?php echo $lang->loc['rss']; ?>" href="<?php echo PATH; ?>/articles/rss.xml" />
<script src="/web-gallery/static/js/libs2.js" type="text/javascript"></script>
<script src="/web-gallery/static/js/landing.js" type="text/javascript"></script>
<link rel="stylesheet" href="/web-gallery/v2/styles/frontpage.css" type="text/css" />
<script src="/web-gallery/static/js/uk.js" type="text/javascript"></script>

<script type="text/javascript">
document.habboLoggedIn = false;
var habboName = null;
var ad_keywords = "";
var habboReqPath = "";
var habboStaticFilePath = "http://images.habbo.com/habboweb/39_35089a85a42fd84d8ff2c7f347a2de46/7/web-gallery";
var habboImagerUrl = "/habbo-imaging/";
var habboPartner = "";
</script>

<style type="text/css">
body {
    background-color: #000;
    
}
#footer .footer-links { color: #666666; }
#footer .footer-links a { color: #b3b3b3; }
#footer .copyright { color: #727272; }    
</style>

<meta name="description" content="<?php echo SHORTNAME; ?> is a virtual world where you can meet and make friends." />
<meta name="keywords" content="<?php echo SHORTNAME; ?>,virtual world,play games,enter competitions,make friends" />


<!--[if IE 8]>
<link rel="stylesheet" href="/web-gallery/v2/styles/ie8.css" type="text/css" />
<![endif]-->
<!--[if lt IE 8]>
<link rel="stylesheet" href="/web-gallery/v2/styles/ie.css" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
<link rel="stylesheet" href="/web-gallery/v2/styles/ie6.css" type="text/css" />
<script src="/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
<script type="text/javascript">
try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
</script>

<style type="text/css">
body { behavior: url(/web-gallery/static/js/csshover.htc); }
</style>
<![endif]-->
</head>
<body id="frontpage">

<div id="fp-container">
    <div id="header" class="clearfix">
        <h1><a href="<?php echo PATH; ?>"></a></h1>
                <span class="login-register-link">
            New here?
            <a href="/register">REGISTER FOR FREE</a>
        </span>
        <a href="/register" class="big-button">
            <table>
                <tr><td align="center" valign="middle">JOIN for FREE!</td></tr>
            </table>
        </a>
    </div>
    <div id="content">
        <div id="column1" class="column">	     		
				<div class="habblet-container ">		
						<div class="logincontainer">
						<?php
if(isset($_SESSION['error'])){
?>
    <div class="action-error flash-message"><div class="rounded"><ul>
        <li><?php echo $_SESSION['error']; ?></li>
    </ul></div></div>
<?php
unset($_SESSION['error']);
}
?>
<div class="cbb loginbox clearfix">

    <h2 class="title">Sign in</h2>
    <div class="box-content clearfix" id="login-habblet">
        <form action="<?php echo PATH; ?>/account/submit" method="post" class="login-habblet">
<?php if(isset($_GET['page'])){ ?><input type="hidden" name="page" value="<?php echo $pageto; ?>" /><?php } ?>
            <ul>
                <li>
                    <label for="login-username" class="login-text">Username</label>
                    <input tabindex="1" type="text" class="login-field" name="username" id="login-username" value="<?php echo $username; ?>" maxlength="32" />
                </li>

                <li>
                    <label for="login-password" class="login-text">Password</label>
                    <input tabindex="2" type="password" class="login-field" name="password" id="login-password" maxlength="32" />
                    <?php if($_SESSION['login']['tries'] > 4 && $settings->find("site_capcha") == "1"){ ?>

                </li>
                <li>
<h3>
<label for="bean_captcha" class="registration-text"><?php echo $lang->loc['type.security.code']; ?></label>
</h3>
<div id="captcha-code-error"></div>
<p></p>
<div class="register-label" id="captcha-reload">
    <p>
        <img src="<?php echo PATH; ?>/web-gallery/v2/images/shared_icons/reload_icon.gif" width="15" height="15" alt=""/>
        <a id="captcha-reload-link" href="#"><?php echo $lang->loc['cannot.read.code']; ?></a>
    </p>
</div>
<script type="text/javascript">
document.observe("dom:loaded", function() {
Event.observe($("captcha-reload"), "click", function(e) {Utils.reloadCaptcha()});
});
</script>
<p id="captcha-container">
    <img id="captcha" src="<?php echo PATH; ?>/captcha.jpg?t=<?php echo time(); ?>" alt="" width="200" height="50" />
</p>
<p>
<input type="text" name="captcha" id="captcha-code" value="" class="registration-text required-captcha" />
</p>
<?php } ?>
                    <input type="submit" value="Sign in" class="submit" id="login-submit-button"/>
                    <a href="#" id="login-submit-new-button" class="new-button" style="margin-left: 0;display:none"><b style="padding-left: 10px; padding-right: 7px; width: 55px">Sign in</b><i></i></a>
                </li>
                <li id="remember-me" class="no-label">
                    <input tabindex="4" type="checkbox" name="_login_remember_me" value="true" id="login-remember-me"<?php if(isset($_GET['rememberme']) && $rememberme = "true"){ echo " checked=\"checked\""; }elseif($rememberme = "false"){ echo " checked=\"unchecked\""; } ?>/>

                    <label for="login-remember-me">Remember me</label>
                </li>
                <li id="register-link" class="no-label">
                    <a href="<?php echo PATH; ?>/register" class="login-register-link"><span>Register for free</span></a>
                </li>
                <li class="no-label">
                    <a href="<?php echo PATH; ?>/account/password/forgot" id="forgot-password"><span>I forgot my password/username</span></a>

                </li>
            </ul>
<div id="remember-me-notification" class="bottom-bubble" style="display:none;">
	<div class="bottom-bubble-t"><div></div></div>
	<div class="bottom-bubble-c">
                By selecting 'remember me' you will stay signed in on this computer until you click 'Sign Out'. If this is a public computer please do not use this feature.
	</div>
	<div class="bottom-bubble-b"><div></div></div>
</div>
        </form>

    </div>
</div>
</div>
<script type="text/javascript">
L10N.put("authentication.form.name", "Username");
L10N.put("authentication.form.password", "Password");
HabboView.add(function() {LoginFormUI.init();});
HabboView.add(function() {window.setTimeout(function() {RememberMeUI.init("newfrontpage");}, 100)});
</script>
				
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
	     		
				<div class="habblet-container ">		
			</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			<div class="habblet-container ">		
	
						<a href="/register" id="frontpage-image" style="background-image: url('web-gallery/v2/images/frontpage/front_page_hotel_with_habbos.png')"><div id="partner-logo"></div></a>
<div style="width: 710px; margin: 0 auto">
<div id="tagline" class="roundedrect"><?php echo FULLNAME; ?> - make friends, join the fun , get noticed!</div>
<div style="height: 2px"></div>
</div>

<a href="/register" class="big-button" onclick="location.href=this.href"> 
    <table>
        <tr><td align="center" valign="middle">JOIN for FREE!</td></tr>
    </table>
</a>
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
  		
				<div class="habblet-container ">		
	
						<div style="width: 710px; margin: 0 auto">
<div class="roundedrect" id="tag-cloud-slim">
    <span class="tags-habbos-like"><?php echo $lang->loc['tags']; ?></span>
<?php
$lang->addLocale("ajax.tags");
$sql = $db->query("SELECT tag, COUNT(id) AS quantity FROM ".PREFIX."tags GROUP BY tag ORDER BY quantity DESC LIMIT 20");
if($db->num_rows($sql) < 1){ echo $lang->loc['no.tags']; }else{
echo "	    <ul class=\"tag-list\">";
	for($i=0;($array[$i] = @    $db->fetch_array($sql,1))!="";$i++)
        {
            $row[] = $array[$i];
        }
	sort($row);
	$i = -1;
	while($i <> $db->num_rows($sql)){
		$i++;
		$tag = $row[$i]['tag'];
		$count = $row[$i]['quantity'];
		$tags[$tag] = $count;
	}
		$max_qty = max(array_values($tags));
		$min_qty = min(array_values($tags));
		$spread = $max_qty - $min_qty;
		if($spread == 0){ $spread = 1; }
		$step = (200 - 100)/($spread);
		foreach($tags as $key => $value){
		    $size = 100 + (($value - $min_qty) * $step);
		    $size = ceil($size);
		    echo "<li><a href=\"".PATH."/tag/".strtolower($input->HoloText($key))."\" class=\"tag\" style=\"font-size:".$size."%\">".trim(strtolower($key))."</a> </li>\n";
		}
echo "</ul>";
}
?>

</div>
</div>
	
						
					

				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			 

</div>
<?php include './templates/login_footer.php'; ?>
