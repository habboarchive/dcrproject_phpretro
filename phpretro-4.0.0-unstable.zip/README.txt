PHPRetro 4.0.0 Beta 3 (Unstable)
www.phpretro.com
=================================================

1. Installation
	i. Common Errors
	ii. Premissions
	iii. Installing Events
	iv. Cron
2. FAQs
3. Troubleshooting

-=Installation=-

To install,
1) Upload all files in the ./upload folder
to your web server.
2) Make sure you have a correct EMPTY Holograph Database, if
you can't find one, use Google or search on RaGEZONE.
3) See "Premissions" for settings correct premissions.
4) Visit the /install page via your web browser
5) Follow the installer
6) Delete the /install folder
7) If PHPRetro is installed anywhere EXCEPT root of your
	web root. (e.x http://www.retro.com/cms/), then you
	must edit .htaccess in the installation folder and
	change the first line to match your directory in order
	to have an error page. So for http://www.retro.com/cms/
	the first line have to be: ErrorDocument 404 /cms/error.php

To migrate (from HoloCMS),
1) Make sure you're using HoloCMS 3.1.1.60, any other version,
	you must upgrade first.
2) Delete ALL HoloCMS files EXCEPT config.php (found in root
	installation directory)
3) Make sure the whole folder is empty EXCEPT config.php
4) Make sure config.php has CHMOD 777 premissions
5) Copy all PHPRetro files from the ./upload folder to the folder
	with config.php
6) See "Premissions" for settings correct premissions.
7) Visit the /install page via your web browser
8) Follow the migration installer
9) Delete the /install folder
10) If PHPRetro is installed anywhere EXCEPT root of your
	web root. (e.x http://www.retro.com/cms/), then you
	must edit .htaccess in the installation folder and
	change the first line to match your directory in order
	to have an error page. So for http://www.retro.com/cms/
	the first line have to be: ErrorDocument 404 /cms/error.php

-Common Errors
* If you are getting premission errors or access denined,
see "Premissions" to make sure you have correct premissions.
Make sure you're already in the installer page, Step 1, then
on your web server, create three BLANK files in the ./includes
folder: config.php, settings.ret, and status.ret. Now CHMOD 777
these files.
* If you are getting SQL errors, make sure your database is 
empty (no users, no cms_ tables, etc)

-Premissions
You must CHMOD 777 these files/folders, if they don't exist, 
create a blank file just to be safe.
./email.log (optional)
./includes/config.php (CHMOD back to 644 after installation)
./includes/settings.ret (create, if not exist)
./includes/status.ret (create, if not exist)
./habbo-imaging/cache (CHMOD 777 the whole folder if asked)

-Installing Events
(For Holograph Emulator ONLY)
1. Replace your current Holograph Emulator eventManager.cs
	(located at Source/Managers) with the one located in the
	do_not_upload folder
2. Compile Holograph Emulator
3. Execute events.sql found in the do_not_upload folder
4. Edit ./includes/data/holograph.php and go to line 218
	Delete Lines 218 - 222. Then delete the comment marks
	above and below the new function select19().

-Cron
(Incomplete)
For advanced users, cron files are in do_not_upload/cron, use 
them as you please.

-=FAQs=-
(Incomplete)

-=Troubleshooting=-
(Incomplete)
* Most errors are caused by either premission errors (see above)
or SQL errors (also see above).
* If you are getting "page not found" errors, make sure you are
	using Apache 2.2 AND have mod_rewrite installed

=================================================
Copyright (C) 2009 Yifan Lu
Parts Copyright (C) 2009 Meth0d
All JS/CSS/Images Copyright (C) 2009 Sulake Ltd.