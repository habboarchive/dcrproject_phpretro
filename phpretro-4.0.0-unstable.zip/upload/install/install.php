<?php
/*================================================================+\
|| # PHPRetro - An extendable virtual hotel site and management
|+==================================================================
|| # Copyright (C) 2009 Yifan Lu. All rights reserved.
|| # http://www.yifanlu.com
|| # Parts Copyright (C) 2009 Meth0d. All rights reserved.
|| # http://www.meth0d.org
|| # All images, scripts, and layouts
|| # Copyright (C) 2009 Sulake Ltd. All rights reserved.
|+==================================================================
|| # PHPRetro is provided "as is" and comes without
|| # warrenty of any kind. PHPRetro is free software!
|| # License: GNU Public License 3.0
|| # http://opensource.org/licenses/gpl-license.php
\+================================================================*/

session_start();
if($_SESSION['install_started'] != true || empty($_SESSION['install_started'])){ header('Location: ./index.php'); exit; }

require_once('./install_functions.php');

$page = (int) $_POST['page']; if(empty($page)){ $page = 1; }
if(!isset($_SESSION['settings'])){ $_SESSION['settings'] = array(); }

if(isset($_POST['submit']) && $_POST['submit'] == "Continue"){
	foreach($_POST as $id => $value){
		if($id == "page"){ continue; }
		$_SESSION['settings'][$id] = $value;
	}
	switch($page){
		case 1:
			if(!isset($_POST['s_site_language']) || empty($_POST['s_site_language'])){
				$error = "You must select a valid language!";
			}
			require_once('../includes/version.php');
			$_SESSION['settings']['s_version'] = serialize(version());
			break;
		case 2:
			foreach($_POST as $value){
				if(empty($value)){
					$error = "You MUST fill in all fields!";
					break;
				}
			}
			if(writeConfig($_POST) == false){
				$error = "Cannot write config file, make sure to chmod ./includes/config.php 777 for now and back to 644 when installation is done.";
				break;
			}
			define('IN_HOLOCMS', true);
			require_once('../includes/config.php');
			require_once('../includes/classes.php');
			$db = new $conn['main']['server']($conn['main']);
			if($db->connection == false){ $error = "Cannot connect to the database server. Please check your settings."; break; }
			break;
		case 3:
			$last = $_POST['s_site_path'][strlen($str)-1];
			if($last == "/"){ $_POST['s_site_path'] = substr_replace($_POST['s_site_path'],"",-1); }
			foreach($_POST as $value){
				if(empty($value)){
					$error = "You MUST fill in all fields!";
					break;
				}
			}
			break;
		case 4:
			$filter = preg_replace("/[^a-z\d\-=\?!@:\.]/i", "", $_POST['admin_username']);
			if($_POST['admin_username'] != $filter){ $error = "Invalid username, you can only use use alpha-numeric characters plus these characters inside the colons: (-=\?!@:.)"; }
			foreach($_POST as $value){
				if(empty($value)){
					$error = "You MUST fill in all fields!";
					break;
				}
			}
			break;
	}
	if(!isset($error)){
		$page++;
	}
}elseif($_POST['submit'] == "Back"){
	$page--;
}

switch($page){
case 1:
$description = "Welcome to PHPRetro! To begin, please choose your language. Please note that while you may change the language anytime, the database will be installed with the following following language and you will have to manually change them if you decide to change the language later.";
$title = "Introduction";
$disable_back = true;
$form = '<input type="hidden" name="page" value="1" /><div class="installer-label white"><label for="s_site_language">Language:</label></div><select name="s_site_language" title="Install all language files to ./includes/languages" class="installer-input">';
if ($handle = opendir('../includes/languages')) {
    while (false !== ($file = readdir($handle))) {
    	if($file == "." || $file == ".."){ continue; }
    	$filename = '../includes/languages/'.$file;
        $fh = fopen($filename, 'r');
        $contents = fread($fh, filesize($filename));
        $lines = split("\n", $contents);
        $name = str_replace('Name: ','',$lines[2]);
        if(isset($_SESSION['settings']['s_site_language']) && $_SESSION['settings']['s_site_language'] == str_replace('.php','',$file)){ $selected = ' selected="true"'; }
        $form .= '<option value="'.str_replace('.php','',$file).'"'.$selected.'>'.$name.'</option>';
    }
    $form .= '</select>';
    closedir($handle);
}
break;
case 2:
if(!isset($_SESSION['settings']['db_prefix'])){ $_SESSION['settings']['db_prefix'] = "cms_"; }
if(!isset($_SESSION['settings']['db_server'])){ $_SESSION['settings']['db_server'] = "mysql"; }
if(!isset($_SESSION['settings']['db_host'])){ $_SESSION['settings']['db_host'] = "localhost"; }
if(!isset($_SESSION['settings']['db_port'])){ $_SESSION['settings']['db_port'] = "3306"; }
if(!isset($_SESSION['settings']['db_username'])){ $_SESSION['settings']['db_username'] = "root"; }
$description = "Please fill in information about the database server PHPRetro will connect to. Note that any existing web site data in the database will be lost (hotel data will not be touched).";
$title = "Database";
$form = '<input type="hidden" name="page" value="2" />';
$form .= '<div class="installer-label white"><label for="db_prefix">Table Prefix:</label></div><input type="text" class="installer-input" name="db_prefix" value="'.$_SESSION['settings']['db_prefix'].'" title="Please choose a prefix for all tables related to PHPRetro. This is for security purposes and to prevent naming collision with the hotel server database." /><br />';
$form .= '<div class="installer-label white"><label for="db_server">Database Server:</label></div><select class="installer-input" name="db_server" title="MySQL is the only database server that is tested to be 100% working. All other database servers have experimental support."><option value="mysql"'; if($_SESSION['settings']['db_server'] == "mysql"){ $form .= ' selected="true"'; }; $form .= '>MySQL</option><option value="pgsql"'; if($_SESSION['settings']['db_server'] == "pgsql"){ $form .= ' selected="true"'; }; $form .= '>PostgreSQL</option><option value="sqlite"'; if($_SESSION['settings']['db_server'] == "sqlite"){ $form .= ' selected="true"'; }; $form .= '>SQLite</option><option value="mssql"'; if($_SESSION['settings']['db_server'] == "mssql"){ $form .= ' selected="true"'; }; $form .= '>Microsoft SQL Server</option></select><br />';
$form .= '<div class="installer-label white"><label for="db_host">Database Host:</label></div><input type="text" class="installer-input" name="db_host" value="'.$_SESSION['settings']['db_host'].'" title="The host of your database server. Chances are that it is localhost." /><br />';
$form .= '<div class="installer-label white"><label for="db_port">Database Port:</label></div><input type="text" class="installer-input" name="db_port" value="'.$_SESSION['settings']['db_port'].'" title="The port of your database server. Chances are that it is 3306 if you are using MySQL." /><br />';
$form .= '<div class="installer-label white"><label for="db_username">Database Username:</label></div><input type="text" class="installer-input" name="db_username" value="'.$_SESSION['settings']['db_username'].'" title="The username to connect to your database server." /><br />';
$form .= '<div class="installer-label white"><label for="db_password">Database Password:</label></div><input type="password" class="installer-input" name="db_password" value="'.$_SESSION['settings']['db_password'].'" title="The password to connect to your database server." /><br />';
$form .= '<div class="installer-label white"><label for="db_name">Database Name:</label></div><input type="text" class="installer-input" name="db_name" value="'.$_SESSION['settings']['db_name'].'" title="The name of the database to connect to. Default for Holograph Emulator is holodb." />';
break;
case 3:
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
$pos = strpos($pageURL,"/install");
$pageURL = substr($pageURL, 0, $pos);
if(!isset($_SESSION['settings']['s_site_name'])){ $_SESSION['settings']['s_site_name'] = "Retro Hotel"; }
if(!isset($_SESSION['settings']['s_site_shortname'])){ $_SESSION['settings']['s_site_shortname'] = "Retro"; }
if(!isset($_SESSION['settings']['s_site_path'])){ $_SESSION['settings']['s_site_path'] = $pageURL; }
$description = "Please fill in the following basic settings to complete the installation. There are more settings in the housekeeping available after the installation.";
$title = "Settings";
$form = '<input type="hidden" name="page" value="3" />';
$form .= '<div class="installer-label white"><label for="s_site_name">Site Name:</label></div><input type="text" class="installer-input" name="s_site_name" maxlength="24" value="'.$_SESSION['settings']['s_site_name'].'" title="This is the full name of your hotel (include the word Hotel if it is part of the name)." /><br />';
$form .= '<div class="installer-label white"><label for="s_site_shortname">Short Name:</label></div><input type="text" class="installer-input" name="s_site_shortname" value="'.$_SESSION['settings']['s_site_shortname'].'" title="Usually a one-word short version of your hotel name." /><br />';
$form .= '<div class="installer-label white"><label for="s_site_path">Site Path:</label></div><input type="text" class="installer-input" name="s_site_path" value="'.$_SESSION['settings']['s_site_path'].'" title="The full URL path to your hotel. No slash (/) at the end." /><br />';
$form .= '<div class="installer-label white"><label for="s_hotel_server">Hotel Server:</label></div><select name="s_hotel_server" title="Install all hotel server definition files to ./includes/data" class="installer-input">';
if ($handle = opendir('../includes/data')) {
    while (false !== ($file = readdir($handle))) {
    	if($file == "." || $file == ".."){ continue; }
    	$filename = '../includes/data/'.$file;
        $fh = fopen($filename, 'r');
        $contents = fread($fh, filesize($filename));
        $lines = split("\n", $contents);
        $name = str_replace('Name: ','',$lines[2]);
        if(isset($_SESSION['settings']['s_hotel_server']) && $_SESSION['settings']['s_hotel_server'] == str_replace('.php','',$file)){ $selected = ' selected="true"'; }
        $form .= '<option value="'.str_replace('.php','',$file).'"'.$selected.'>'.$name.'</option>';
    }
    $form .= '</select>';
    closedir($handle);
}
break;
case 4:
$description = "Create an administrator account. You may change additional settings once the site is set up.";
$title = "Administrator Account";
$form = '<input type="hidden" name="page" value="4" />';
$form .= '<div class="installer-label white"><label for="admin_username">Username:</label></div><input type="text" class="installer-input" name="admin_username" value="'.$_SESSION['settings']['admin_username'].'" title="Username used for logging in. You may ONLY use alpha-numeric characters plus these characters inside the colons: (-=\?!@:.)." /><br />';
$form .= '<div class="installer-label white"><label for="admin_password">Password:</label></div><input type="password" class="installer-input" name="admin_password" value="'.$_SESSION['settings']['admin_password'].'" title="Your password. Make it strong as you will be administrating the site." /><br />';
$form .= '<div class="installer-label white"><label for="admin_email">Email Address:</label></div><input type="text" class="installer-input" name="admin_email" value="'.$_SESSION['settings']['admin_email'].'" title="A valid email." /><br />';
break;
case 5:
$description = "Please wait while the database is being filled. Do NOT stop, go back, or close this script before completion.";
$title = "Installing";
$disable_back = true;
$disable_continue = true;
$installing = true;
break;
}

require_once('./installer_header.php');
?>
<div id="container">
	<div class="cbb process-template-box clearfix">
		<div id="content">
			<div id="header" class="clearfix">
				<h1><a href="#"></a></h1>
				<ul class="stats">
					    <li class="stats-online"><span class="stats-fig"><?php echo $page; ?>/5</span> <?php echo $title; ?></li>
				</ul>
			</div>
			<div id="process-content">
		<div id="column1" class="column">
			     		
				<div class="habblet-container ">		
	    <form method="post" action="./install.php" autocomplete="off">

	        <div id="installer-column-left" >

            <div id="installer-section-left">
	            <div class="cbb clearfix gray">
	            	<div class="box-content">
	                	<div class="installer-description"><label><?php echo $description; ?></label></div>
		            </div>
	            </div>
	        </div>


        </div>
        <div id="installer-column-right">

            <div id="installer-section-right">
            <?php if(isset($error)){ ?>
            	<div class="installer-error">
                	<div class="rounded rounded-red">
                    	<?php echo $error; ?>
                	</div>
                </div>
            <?php } ?>
                <div class="rounded rounded-blue">
                    <h2 class="heading"><?php echo $title; ?></h2>

                    <fieldset id="installer-fieldset">
						<?php if(isset($form) && !empty($form)){ echo $form; } ?>
						<?php if($installing == true){ installDB(); } ?>
                    </fieldset>

                </div>
            </div>

            <div id="installer-buttons">
                <?php if(!$disable_continue){ ?><input type="submit" name="submit" value="Continue" class="continue" id="installer-button-continue" /><?php } ?>
                <?php if(!$disable_back){ ?><input type="submit" name="submit" value="Back" class="back" id="installer-button-back" /><?php } ?>

            </div>
	    </div>
    </form>
	
						
							
					
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>

			 

</div>
<?php require_once('./installer_footer.php'); ?>