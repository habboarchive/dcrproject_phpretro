<?php
/*================================================================+\
|| # PHPRetro - An extendable virtual hotel site and management
|+==================================================================
|| # Copyright (C) 2009 Yifan Lu. All rights reserved.
|| # http://www.yifanlu.com
|| # Parts Copyright (C) 2009 Meth0d. All rights reserved.
|| # http://www.meth0d.org
|| # All images, scripts, and layouts
|| # Copyright (C) 2009 Sulake Ltd. All rights reserved.
|+==================================================================
|| # PHPRetro is provided "as is" and comes without
|| # warrenty of any kind. PHPRetro is free software!
|| # License: GNU Public License 3.0
|| # http://opensource.org/licenses/gpl-license.php
\+================================================================*/
?>

<!--[if lt IE 7]>
<script type="text/javascript">
Pngfix.doPngImageFix();
</script>
<![endif]-->

<div id="footer">
		<p>Powered by <a href="http://www.phpretro.com/">PHPRetro</a> &copy 2009 <a href="http://www.yifanlu.com/">Yifan Lu</a>, Based on HoloCMS By <a href="http://www.meth0d.org">Meth0d</a><br />HABBO is a installered trademark of Sulake Corporation. All rights reserved to their respective owner(s).</p>

	</div>			</div>
        </div>
    </div>
</div>

<script type="text/javascript">
HabboView.run();
</script>

</body>
</html>