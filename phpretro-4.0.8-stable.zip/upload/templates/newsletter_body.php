<?php
/*================================================================+\
|| # PHPRetro - An extendable virtual hotel site and management
|+==================================================================
|| # Copyright (C) 2009 Yifan Lu. All rights reserved.
|| # http://www.yifanlu.com
|| # Parts Copyright (C) 2009 Meth0d. All rights reserved.
|| # http://www.meth0d.org
|| # All images, scripts, and layouts
|| # Copyright (C) 2009 Sulake Ltd. All rights reserved.
|+==================================================================
|| # PHPRetro is provided "as is" and comes without
|| # warrenty of any kind. PHPRetro is free software!
|| # License: GNU Public License 3.0
|| # http://opensource.org/licenses/gpl-license.php
\+================================================================*/

if (!defined("IN_HOLOCMS")) { header("Location: ".PATH."/"); exit; }
?>
<table width="362" cellspacing="0" cellpadding="0">

<tbody><tr><td width="362" height="125" background="<?php echo PATH; ?>/web-gallery/newsletter/images/topstory_HabboIsland_01.gif" style="margin-left: 0px;"></td></tr>

<tr><td width="362" background="<?php echo PATH; ?>/web-gallery/newsletter/images/article_mid.gif" style="margin-left: 0px; padding-left: 15px; padding-top: 5px; padding-right: 10px;">

<h1 style="font-size: 13px; font-family: verdana,times,times new roman; color: rgb(71, 131, 157);">[MESSAGE HEADER]</h1>

<p style="font-size: 12px; font-family: verdana,times,times new roman; color: black;">[NEWSLETTER MESSAGE]</p>
<span style="font-family: verdana,times,times new roman;"></span>

</td> </tr>

<tr> <td width="362" height="39" background="<?php echo PATH; ?>/web-gallery/newsletter/images/article_bottom_button.gif" style="padding-right: 35px;">

<p align="right" style="font-size: 10px; font-family: verdana,times,times new roman; color: white; font-weight: bold;"><span style="text-decoration: underline;"><a href="<?php echo PATH; ?>/" style="color: white; text-decoration: none; font-size: 10px;" target="_blank">Visit '.SHORTNAME.'</a></span></p>

</td> </tr>

</tbody></table>

<br />

</td><td width="210" valign="top" align="center">

<table width="189" cellspacing="0" cellpadding="0">

<tbody><tr> <td width="189" height="27" background="<?php echo PATH; ?>/web-gallery/newsletter/images/feature_top.gif" style="margin-left: 0px; padding-left: 15px; padding-top: 5px;">

<h1 style="font-size: 10px; font-family: verdana,times,times new roman; color: white;">[RIGHT SIDEBAR HEADER]</h1>

</td></tr>

<tr><td width="189" background="<?php echo PATH; ?>/web-gallery/newsletter/images/feature_mid.gif">

<div align="center"><a href="<?php echo PATH; ?>/"><img border="0" src="<?php echo PATH; ?>/web-gallery/newsletter/images/trax1.gif" /></a><br>
</div><p align="center" style="font-size: 12px; font-family: verdana,times,times new roman; color: black;">[RIGHT SIDEBAR MESSAGE]</p>

</td> </tr>

<tr> <td width="189" height="39" background="<?php echo PATH; ?>/web-gallery/newsletter/images/feature_bottom_button.gif" style="padding-right: 35px; margin-top: 0px;">

<p align="right" style="font-size: 10px; font-family: verdana,times,times new roman; color: white; font-weight: bold;"><a href="<?php echo PATH; ?>/" style="color: white; text-decoration: none; font-size: 10px;" target="_blank">To '.SHORTNAME.'</a></p>

</td> </tr>

</tbody></table>

<br />