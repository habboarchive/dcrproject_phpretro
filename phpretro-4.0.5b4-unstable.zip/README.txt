PHPRetro 4.0 Beta 3 (Unstable)
www.phpretro.com
=================================================

1. Installation
	i. Common Errors
	ii. Premissions
	iii. Installing Events
	iv. Cron
2. FAQs
3. Troubleshooting

-=Installation=-

To install,
1) Upload all files in the ./upload folder
to your web server.
2) Make sure you have a correct EMPTY Holograph Database, if
you can't find one, use Google or search on RaGEZONE.
3) See "Premissions" for settings correct premissions.
4) Visit the /install page via your web browser
5) Follow the installer
6) MOVE /install/config.php TO /includes/config.php
7) Delete the /install folder
8) If PHPRetro is installed anywhere EXCEPT root of your
	web root. (e.x http://www.retro.com/cms/), then you
	must edit .htaccess in the installation folder and
	change the first line to match your directory in order
	to have an error page. So for http://www.retro.com/cms/
	the first line have to be: ErrorDocument 404 /cms/error.php

To migrate (from HoloCMS),
1) Make sure you're using HoloCMS 3.1.1.60, any other version,
	you must upgrade first.
2) Delete ALL HoloCMS files EXCEPT config.php (found in root
	installation directory)
3) Make sure the whole folder is empty EXCEPT config.php
4) Make sure config.php has CHMOD 777 premissions
5) Copy all PHPRetro files from the ./upload folder to the folder
	with config.php
6) See "Premissions" for settings correct premissions.
7) Visit the /install page via your web browser
8) Follow the migration installer
9) MOVE /install/config.php TO /includes/config.php
10) Delete the /install folder
11) If PHPRetro is installed anywhere EXCEPT root of your
	web root. (e.x http://www.retro.com/cms/), then you
	must edit .htaccess in the installation folder and
	change the first line to match your directory in order
	to have an error page. So for http://www.retro.com/cms/
	the first line have to be: ErrorDocument 404 /cms/error.php

-Common Errors
* If you get a error about config.php not being found after 
	installing, make sure you moved config.php from ./install/
	to ./includes/
* If you're using Holograph TdBP edition or one based off of it,
	please note that it is not 100% supported, it will takes some
	tweaks to get everything working including client.php, I'll 
	create a config file for TdBP edition after PHPRetro is stable,
	until then, either try to tweak it to work for yourself, or use
	another version.

-Premissions
You must CHMOD 777 these folders
./cache/ (whole folder)
./install/ (whole folder)

-Installing Events
(For Holograph Emulator ONLY)
1. Replace your current Holograph Emulator eventManager.cs
	(located at Source/Managers) with the one located in the
	do_not_upload folder
2. Compile Holograph Emulator
3. Execute events.sql found in the do_not_upload folder
4. Edit ./includes/data/holograph.php and go to line 218
	Delete Lines 218 - 222. Then delete the comment marks
	above and below the new function select19().

-Cron
(Incomplete)
For advanced users, cron files are in do_not_upload/cron, use 
them as you please.

-=FAQs=-
(Incomplete)

-=Troubleshooting=-
(Incomplete, see Common Errors)

=================================================
Copyright (C) 2009 Yifan Lu
All JS/CSS/Images Copyright (C) 2009 Sulake Ltd.