<?php
/*================================================================+\
|| # PHPRetro - An extendable virtual hotel site and management
|+==================================================================
|| # Copyright (C) 2009 Yifan Lu. All rights reserved.
|| # http://www.yifanlu.com
|| # Parts Copyright (C) 2009 Meth0d. All rights reserved.
|| # http://www.meth0d.org
|| # All images, scripts, and layouts
|| # Copyright (C) 2009 Sulake Ltd. All rights reserved.
|+==================================================================
|| # PHPRetro is provided "as is" and comes without
|| # warrenty of any kind. PHPRetro is free software!
|| # License: GNU Public License 3.0
|| # http://opensource.org/licenses/gpl-license.php
\+================================================================*/

if (!defined("IN_HOLOCMS")) { header("Location: ".PATH."/"); exit; }
$lang->addLocale("newsletter.header.footer");
?>
<style type="text/css">
<!--
.style1 {font-family: Verdana, Arial, Helvetica, sans-serif}
-->
</style>
<table width="576" cellspacing="0" cellpadding="0" border="0" background="<?php echo PATH; ?>/web-gallery/newsletter/images/email_bg.gif" style="margin: 20px 20px 20px 40px;">

<tbody><tr> <td width="576" height="20" bgcolor="white" align="center" colspan="4" style="margin: 0px;"> <p align="center" style="font-size: 10px; color: black; font-family: verdana,times,times new roman; font-weight: bold;"><b><?php echo $lang->loc['add.email']; ?></b></p></td></tr>

<tr> <td width="576" height="79" bgcolor="white" background="<?php echo PATH; ?>/web-gallery/newsletter/images/email_Header.gif" colspan="4" style="margin: 0px;"></td></tr>

<tr> <td width="5" background="<?php echo PATH; ?>/web-gallery/newsletter/images/outline.gif"> </td>

<td>

<table width="566" height="100%" cellspacing="0" cellpadding="0" border="0" style="padding-left: 5px; padding-top: 5px;">

<tbody><tr> <td width="366" valign="top" align="left">

