<?php
/*================================================================+\
|| # PHPRetro - An extendable virtual hotel site and management
|+==================================================================
|| # Copyright (C) 2009 Yifan Lu. All rights reserved.
|| # http://www.yifanlu.com
|| # Parts Copyright (C) 2009 Meth0d. All rights reserved.
|| # http://www.meth0d.org
|| # All images, scripts, and layouts
|| # Copyright (C) 2009 Sulake Ltd. All rights reserved.
|+==================================================================
|| # PHPRetro is provided "as is" and comes without
|| # warrenty of any kind. PHPRetro is free software!
|| # License: GNU Public License 3.0
|| # http://opensource.org/licenses/gpl-license.php
\+================================================================*/

if (!defined("IN_HOLOCMS")) { header("Location: ".PATH."/"); exit; }
?>
<html><head><style type="text/css">
a { color: #fc6204; }
</style></head>
<body style="background-color: #e3e3db; margin: 0; padding: 0; font-size: 11px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #000;">

<div style="background-color: #bce0ee; padding: 14px; border-bottom: 3px solid #000;">
	<img src="cid:habbologo" alt="<?php echo PATH; ?>" width="160" height="66" />
</div>

<div style="padding: 14px 14px 50px 14px; background-color: #e3e3db;">
	<div style="background-color: #fff; padding: 14px; border: 1px solid #ccc">
