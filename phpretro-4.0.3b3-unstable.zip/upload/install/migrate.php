<?php
/*================================================================+\
|| # PHPRetro - An extendable virtual hotel site and management
|+==================================================================
|| # Copyright (C) 2009 Yifan Lu. All rights reserved.
|| # http://www.yifanlu.com
|| # Parts Copyright (C) 2009 Meth0d. All rights reserved.
|| # http://www.meth0d.org
|| # All images, scripts, and layouts
|| # Copyright (C) 2009 Sulake Ltd. All rights reserved.
|+==================================================================
|| # PHPRetro is provided "as is" and comes without
|| # warrenty of any kind. PHPRetro is free software!
|| # License: GNU Public License 3.0
|| # http://opensource.org/licenses/gpl-license.php
\+================================================================*/

session_start();
if($_SESSION['install_started'] != true || empty($_SESSION['install_started'])){ header('Location: ./index.php'); exit; }

require_once('./migrate_functions.php');

$page = (int) $_POST['page']; if(empty($page)){ $page = 1; }
if(!isset($_SESSION['settings'])){ $_SESSION['settings'] = array(); }

if(isset($_POST['submit']) && $_POST['submit'] == "Continue"){
	foreach($_POST as $id => $value){
		if($id == "page"){ continue; }
		$_SESSION['settings'][$id] = $value;
	}
	switch($page){
		case 1:
			if(!isset($_POST['s_site_language']) || empty($_POST['s_site_language'])){
				$error = "You must select a valid language!";
			}
			if(!file_exists('../config.php')){
				$error = "Cannot find your old HoloCMS config.php. If you accidentally deleted it, please find another copy and place it in the root of PHPRetro. If this is a new installation, please go to /install/install.php";
			}
			require_once('../includes/version.php');
			$_SESSION['settings']['s_version'] = serialize(version());
			break;
		case 2:
			foreach($_POST as $value){
				if(empty($value)){
					$error = "You MUST fill in all fields!";
					break;
				}
			}
			if(writeConfig($_POST) == false){
				$error = "Cannot write config file, make sure to chmod ./includes/config.php 777 for now and back to 644 when installation is done.";
				break;
			}
			define('IN_HOLOCMS', true);
			require_once('../includes/config.php');
			require_once('../includes/classes.php');
			$db = new $conn['main']['server']($conn['main']);
			if($db->connection == false){ $error = "Cannot connect to the database server. Please check your settings."; break; }
			break;
	}
	if(!isset($error)){
		$page++;
	}
}elseif($_POST['submit'] == "Back"){
	$page--;
}

switch($page){
case 1:
$description = "Welcome to PHPRetro! This script will attempt to migrate existing HoloCMS data to the new PHPRetro format. This script is only compatible with HoloCMS 3.1.1.60 with Holograph Emulator. If you are using a previous version, please upgrade to revision 60 before continuing. MAKE SURE YOU BACKED UP YOUR DATABASE, WITHER THIS SCRIPT SUCCEEDS OR FAILS, ALL YOUR PREVIOUS HOLOCMS DATA WILL BE LOST! To begin, please choose your language. Please note that while you may change the language anytime, the database will be installed with the following following language and you will have to manually change them if you decide to change the language later.";
$title = "Introduction";
$disable_back = true;
$form = '<input type="hidden" name="page" value="1" /><div class="installer-label white"><label for="s_site_language">Language:</label></div><select name="s_site_language" title="Install all language files to ./includes/languages" class="installer-input">';
if ($handle = opendir('../includes/languages')) {
    while (false !== ($file = readdir($handle))) {
    	if($file == "." || $file == ".."){ continue; }
    	if(substr($file,-4) != ".php"){ continue; }
    	$filename = '../includes/languages/'.$file;
        $fh = fopen($filename, 'r');
        $contents = fread($fh, filesize($filename));
        $lines = split("\n", $contents);
        $name = str_replace('Name: ','',$lines[2]);
        if(isset($_SESSION['settings']['s_site_language']) && $_SESSION['settings']['s_site_language'] == str_replace('.php','',$file)){ $selected = ' selected="true"'; }
        $form .= '<option value="'.str_replace('.php','',$file).'"'.$selected.'>'.$name.'</option>';
    }
    $form .= '</select>';
    closedir($handle);
}
break;
case 2:
require('../config.php');
if($encryption != "new"){ $error = "It seems like your users table isn't using the new encryption method. While you can continue to migrate, please note that no users can login anymore and must reset their passwords. The next step may take a long time to finish, so please be patient."; }
if($enable_status_image == "1"){ $_SESSION['settings']['s_site_status_image'] = "2"; }else{ $_SESSION['settings']['s_site_status_image'] = "0"; }
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
$pos = strpos($pageURL,"/install");
$pageURL = substr($pageURL, 0, $pos);
$_SESSION['settings']['s_site_path'] = $pageURL;
$_SESSION['settings']['s_register_referral_rewards'] = $reward;
$_SESSION['settings']['s_site_c_images_path'] = $cimagesurl;
$_SESSION['settings']['s_site_badges_path'] = $badgesurl;
$_SESSION['settings']['s_email_verify_enabled'] = (int) $email_verify;
$_SESSION['settings']['s_email_verify_reward'] = $email_verify_reward;
if(!isset($_SESSION['settings']['db_prefix'])){ $_SESSION['settings']['db_prefix'] = "cms_"; }
if(!isset($_SESSION['settings']['db_server'])){ $_SESSION['settings']['db_server'] = "mysql"; }
if(!isset($_SESSION['settings']['db_host'])){ $_SESSION['settings']['db_host'] = $sqlhostname; }
if(!isset($_SESSION['settings']['db_port'])){ $_SESSION['settings']['db_port'] = "3306"; }
if(!isset($_SESSION['settings']['db_username'])){ $_SESSION['settings']['db_username'] = $sqlusername; }
if(!isset($_SESSION['settings']['db_password'])){ $_SESSION['settings']['db_password'] = $sqlpassword; }
if(!isset($_SESSION['settings']['db_name'])){ $_SESSION['settings']['db_name'] = $sqldb; }
$description = "The following infomation has been imported from your old HoloCMS config.php. Make sure they are correct and press Continue to migrate your old HoloCMS installation to PHPRetro.";
$title = "Database";
$form = '<input type="hidden" name="page" value="2" />';
$form .= '<div class="installer-label white"><label for="db_prefix">Table Prefix:</label></div><input type="text" class="installer-input" name="db_prefix" value="'.$_SESSION['settings']['db_prefix'].'" title="Please choose a prefix for all tables related to PHPRetro. This is for security purposes and to prevent naming collision with the hotel server database." /><br />';
$form .= '<div class="installer-label white"><label for="db_server">Database Server:</label></div><select class="installer-input" name="db_server" title="MySQL is the only database server that is tested to be 100% working. All other database servers have experimental support."><option value="mysql"'; if($_SESSION['settings']['db_server'] == "mysql"){ $form .= ' selected="true"'; }; $form .= '>MySQL</option><option value="pgsql"'; if($_SESSION['settings']['db_server'] == "pgsql"){ $form .= ' selected="true"'; }; $form .= '>PostgreSQL</option><option value="sqlite"'; if($_SESSION['settings']['db_server'] == "sqlite"){ $form .= ' selected="true"'; }; $form .= '>SQLite</option><option value="mssql"'; if($_SESSION['settings']['db_server'] == "mssql"){ $form .= ' selected="true"'; }; $form .= '>Microsoft SQL Server</option></select><br />';
$form .= '<div class="installer-label white"><label for="db_host">Database Host:</label></div><input type="text" class="installer-input" name="db_host" value="'.$_SESSION['settings']['db_host'].'" title="The host of your database server. Chances are that it is localhost." /><br />';
$form .= '<div class="installer-label white"><label for="db_port">Database Port:</label></div><input type="text" class="installer-input" name="db_port" value="'.$_SESSION['settings']['db_port'].'" title="The port of your database server. Chances are that it is 3306 if you are using MySQL." /><br />';
$form .= '<div class="installer-label white"><label for="db_username">Database Username:</label></div><input type="text" class="installer-input" name="db_username" value="'.$_SESSION['settings']['db_username'].'" title="The username to connect to your database server." /><br />';
$form .= '<div class="installer-label white"><label for="db_password">Database Password:</label></div><input type="password" class="installer-input" name="db_password" value="'.$_SESSION['settings']['db_password'].'" title="The password to connect to your database server." /><br />';
$form .= '<div class="installer-label white"><label for="db_name">Database Name:</label></div><input type="text" class="installer-input" name="db_name" value="'.$_SESSION['settings']['db_name'].'" title="The name of the database to connect to. Default for Holograph Emulator is holodb." />';
$form .= '<div class="installer-label white"><label for="s_site_path">Site Path:</label></div><input type="text" class="installer-input" name="s_site_path" value="'.$_SESSION['settings']['s_site_path'].'" title="The full URL path to your hotel. No slash (/) at the end." /><br />';
break;
case 3:
$description = "Please wait while the database is being migrated. Do NOT stop, go back, or close this script before completion.";
$title = "Migrating";
$disable_back = true;
$disable_continue = true;
$installing = true;
break;
}

require_once('./installer_header.php');
?>
<div id="container">
	<div class="cbb process-template-box clearfix">
		<div id="content">
			<div id="header" class="clearfix">
				<h1><a href="#"></a></h1>
				<ul class="stats">
					    <li class="stats-online"><span class="stats-fig"><?php echo $page; ?>/3</span> <?php echo $title; ?></li>
				</ul>
			</div>
			<div id="process-content">
		<div id="column1" class="column">
			     		
				<div class="habblet-container ">		
	    <form method="post" action="./migrate.php" autocomplete="off">

	        <div id="installer-column-left" >

            <div id="installer-section-left">
	            <div class="cbb clearfix gray">
	            	<div class="box-content">
	                	<div class="installer-description"><label><?php echo $description; ?></label></div>
		            </div>
	            </div>
	        </div>


        </div>
        <div id="installer-column-right">

            <div id="installer-section-right">
            <?php if(isset($error)){ ?>
            	<div class="installer-error">
                	<div class="rounded rounded-red">
                    	<?php echo $error; ?>
                	</div>
                </div>
            <?php } ?>
                <div class="rounded rounded-blue">
                    <h2 class="heading"><?php echo $title; ?></h2>

                    <fieldset id="installer-fieldset">
						<?php if(isset($form) && !empty($form)){ echo $form; } ?>
						<?php if($installing == true){ migrateDB(); } ?>
                    </fieldset>

                </div>
            </div>

            <div id="installer-buttons">
                <?php if(!$disable_continue){ ?><input type="submit" name="submit" value="Continue" class="continue" id="installer-button-continue" /><?php } ?>
                <?php if(!$disable_back){ ?><input type="submit" name="submit" value="Back" class="back" id="installer-button-back" /><?php } ?>

            </div>
	    </div>
    </form>
	
						
							
					
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>

			 

</div>
<?php require_once('./installer_footer.php'); ?>