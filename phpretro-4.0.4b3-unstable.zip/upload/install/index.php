<?php
/*================================================================+\
|| # PHPRetro - An extendable virtual hotel site and management
|+==================================================================
|| # Copyright (C) 2009 Yifan Lu. All rights reserved.
|| # http://www.yifanlu.com
|| # Parts Copyright (C) 2009 Meth0d. All rights reserved.
|| # http://www.meth0d.org
|| # All images, scripts, and layouts
|| # Copyright (C) 2009 Sulake Ltd. All rights reserved.
|+==================================================================
|| # PHPRetro is provided "as is" and comes without
|| # warrenty of any kind. PHPRetro is free software!
|| # License: GNU Public License 3.0
|| # http://opensource.org/licenses/gpl-license.php
\+================================================================*/

session_start();
if(isset($_GET['installed']) && $_GET['installed'] == "success"){
	$_SESSION = array(); @session_destroy();
	$page['dir'] = '\install';
	//require_once('../includes/core.php');
	//$settings->generateCache();
	$title = "Success";
	$color = "rounded rounded-green";
	$message = "To finish the installation, please <strong>move ./install/config.php to ./includes/config.php and DELETE the ./install folder</strong> for security reasons, and then you may proceed to the <a href=\"../\">Front Page</a> or <a href=\"../housekeeping/\">Housekeeping</a> and change additional settings.";
}elseif(file_exists('../includes/config.php') && $_GET['bypass'] != "true"){
	$page['dir'] = '\install';
	require_once('../includes/core.php');
	
	$version = unserialize($settings->find("version"));
	$new_version = version();
	
	if($new_version['revision'] > $version['revision']){
		$_SESSION['from_version'] = $version;
		$_SESSION['install_started'] = true;
		$n = $version['revision'];
		while($n < $new_version['revision']){
		 if(file_exists('./install/upgrade_'.$n.'.php')){
		 	header('Location: '.PATH.'/install/upgrade_'.$n.'.php');
		 	exit; break;
		 }
		 $n++;
		}
		$title = "Error";
		$color = "rounded rounded-red";
		$message = "There does not seem to be any available upgrade for your installed version.";
	}elseif($new_version['revision'] == $version['revision']){
		$title = "Error";
		$color = "rounded rounded-red";
		$message = "PHPRetro is already installed. Please delete the ./install folder for security purposes. If you would like to run the installer anyways, <a href=\"./index.php?bypass=true\">click here</a> to continue. Please note that doing so will cause you to lose all site data.";
	}else{
		$title = "Error";
		$color = "rounded rounded-red";
		$message = "You are trying to install an older version of PHPRetro. Downgrading is not available.";
	}
}elseif(file_exists('../config.php')){
	$_SESSION['install_started'] = true;
	header('Location: ./migrate.php'); exit;
}else{
	$_SESSION['install_started'] = true;
	header('Location: ./install.php'); exit;
}

require_once('../install/installer_header.php');
?>
<div id="container">
	<div class="cbb process-template-box clearfix">
		<div id="content">
			<div id="header" class="clearfix">
				<h1><a href="#"></a></h1>
				<ul class="stats">
					    <li class="stats-online"><span class="stats-fig"><?php echo $title; ?></span></li>
				</ul>
			</div>
		<div id="column1" class="column">
			     		
				<div class="habblet-container ">		

	        <div id="installer-column-left" >

            <div id="installer-section-left">
	        </div>


        </div>
        <div id="installer-column-right">

            <div id="installer-section-right">
            	<div class="installer-error">
                	<div class="<?php echo $color; ?>">
                    	<?php echo $message; ?>
                	</div>
                </div>
            </div>
	    </div>
    </form>
	
						
							
					
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>

			 

</div>
<?php require_once('../install/installer_footer.php'); ?>